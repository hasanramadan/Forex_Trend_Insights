<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forex Trend Insights</title>

    <!-- Link our CSS file -->
    <link rel="stylesheet" href="config/style.css">
</head>

<body class="body">

    <div class="slide-in-div">
        
        <div class="container text-center">
        <img src="images/home.jpg" class="img50"></img>
        <h1 class="text-black h1">Understand the world through currency data </h1>
        <p class="quote text-black">The most powerful tool for understanding global markets</p>
        <a href="choose_currency.php" class="btn btn-primary">Get Started</a>
        </div>
    </div>
    <script src="config/script.js"></script>
</body>

</html>
