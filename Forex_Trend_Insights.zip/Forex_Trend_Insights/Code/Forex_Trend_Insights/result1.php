<!DOCTYPE html>

<html lang="en">

<?php include('config/nav.php'); ?>

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Results</title>
</head>

<body>
    <?php


    if (isset($_POST['start_date'], $_POST['currency'], $_POST['days'], $_POST['ATR_(Volatility)'])) {

        $start_date = $_POST['start_date'];

        $currency = $_POST['currency'];

        $nb_days = $_POST['days'];

        $threshold = $_POST['ATR_(Volatility)'];
    } else {
        echo ('error passing information');
    }


    if ($currency == 'gold') {

        $table = 'gold_prices';
    }
    if ($currency == 'platinum') {

        $table = 'platinum_prices';
    }
    if ($currency == 'silver') {

        $table = 'silver_prices';
    }

    $sql = "SELECT * FROM $table WHERE DATE(date) <= '$start_date' ORDER BY date DESC LIMIT $nb_days";
    $res = mysqli_query($mysqli, $sql); //execute the query

    //check if success

    $closing_prices_array_r = [];
    $dates_array_r = [];
    $id_array_r = [];

    if ($res == true) {

        $count = mysqli_num_rows($res); //to get count of rows in db corresponding to the query

        if ($count > 0) {

            while ($rows = mysqli_fetch_assoc($res)) //get the row and store it in $rows then loop for the rest
            {
                //this will run as long as we have data in db
                $id_user_selection = $rows['id'];
                $user_selected_date = $rows['date'];
                $user_timestamp = strtotime($user_selected_date);
                $user_date = date('Y-m-d', $user_timestamp); //to get the date from db without the time
                $close_user_selection = $rows['close'];

                //now to display the data in table we break the php to add html
                array_push($closing_prices_array_r, $close_user_selection);
                array_push($dates_array_r, $user_date);
                array_push($id_array_r, $id_user_selection);
            }
        }
    } else {
        echo ('query fail');
    }

    $closing_prices_array = array_reverse($closing_prices_array_r);
    $dates_array = array_reverse($dates_array_r);
    $id_array = array_reverse($id_array_r);

    $distances_array = [];

    for ($i = 0; $i < $nb_days; $i++) {

        if ($i == $nb_days - 1) { //stop at last element so that we do not get out of index in the array
            break;
        } else {
            $dist = sqrt(abs(pow($closing_prices_array[$i], 2) - pow($closing_prices_array[$i + 1], 2))); //eucildean distance
        }

        array_push($distances_array, $dist);
    }

    $variation_array = [];

    for ($i = 0; $i < $nb_days; $i++) {

        if ($i == $nb_days - 1) { //stop at last element so that we do not get out of index in the array
            break;
        } else {
            if ($closing_prices_array[$i] < $closing_prices_array[$i + 1]) {
                $var = 'high';
            } elseif ($closing_prices_array[$i] > $closing_prices_array[$i + 1]) {
                $var = 'low';
            } else {
                $var = 'breakeven';
            }
        }

        array_push($variation_array, $var);
    }

    $off = 0; //offset to skip already viseted rows in the db
    $closing_prices_array_db = [];
    $distances_array_db = [];
    $variation_array_db = [];
    $id_array_db = [];
    $dates_array_db = [];
    $matching_patterns = [];
    $table_nb = 1;
    $count = $nb_days;

    do {
        $sql1 = "SELECT * FROM $table ORDER BY date ASC LIMIT $nb_days OFFSET $off";
        $res1 = mysqli_query($mysqli, $sql1); //execute the query
        if ($res1 == true) {

            $count = mysqli_num_rows($res1); //to get count of rows in db corresponding to the query

            if ($count > 0) {

                while ($rows1 = mysqli_fetch_assoc($res1)) { //get the row and store it in $rows then loop for the rest

                    //this will run as long as we have data in db
                    $id = $rows1['id'];
                    $selected_date = $rows1['date'];
                    $timestamp = strtotime($selected_date);
                    $date = date('Y-m-d', $timestamp); //to get the date from db without the time
                    $close = $rows1['close'];

                    array_push($closing_prices_array_db, $close);
                    array_push($dates_array_db, $date);
                    array_push($id_array_db, $id);
                }
            }
        } else {
            echo ('query fail');
        }

        $off += $nb_days;

        if ($count == $nb_days) { //to avoid array index errors if the remaining rows in db do not match with the number of days selected break the loop

            //calculating distances

            for ($i = 0; $i < $count; $i++) {

                if ($i == $count - 1) { //stop at last element so that we do not get out of index in the array
                    break;
                } else {
                    $dist = sqrt(abs(pow($closing_prices_array_db[$i], 2) - pow($closing_prices_array_db[$i + 1], 2))); //eucildean distance
                    array_push($distances_array_db, $dist);
                }
            }

            //calculating variations

            for ($i = 0; $i < $count; $i++) {

                if ($i == $count - 1) { //stop at last element so that we do not get out of index in the array
                    break;
                } else {
                    if ($closing_prices_array_db[$i] < $closing_prices_array_db[$i + 1]) {
                        $var = 'high';
                    } elseif ($closing_prices_array_db[$i] > $closing_prices_array_db[$i + 1]) {
                        $var = 'low';
                    } else {
                        $var = 'breakeven';
                    }
                    array_push($variation_array_db, $var);
                }
            }

            //check if the Euclidean distances are within threshold
            $check_d = 0;
            $distances_threshold_match = 0;

            for ($i = 0; $i < count($distances_array); $i++) {

                if (abs($distances_array[$i] - $distances_array_db[$i]) <= $threshold) {
                    $distances_threshold_match = 1;
                    $check_d++;
                }
            }

            if ($check_d != count($distances_array)) {
                $distances_threshold_match = 0;
            }

            //check for the variations match
            $variation_match = 0;
            $check_v = 0;
            for ($i = 0; $i < count($variation_array); $i++) {

                if ($variation_array[$i] == $variation_array_db[$i]) {
                    $variation_match = 1;
                    $check_v++;
                }
            }

            $match_lvl = $check_v / count($variation_array);

            if ($match_lvl != 1) {
                $variation_match = 0;
            }

            if ($variation_match == 1 && $distances_threshold_match == 1) {

                $datesJson = json_encode($dates_array);
                $pricesJson = json_encode($closing_prices_array);

                $datesJson_db = json_encode($dates_array_db);
                $pricesJson_db = json_encode($closing_prices_array_db);

    ?>

                <div class="container text-center">

                    <h3>Match number <?php echo ($table_nb); ?></h3><br><br>

                    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

                    <script type="text/javascript">
                        google.charts.load('current', {
                            'packages': ['corechart']
                        });
                        google.charts.setOnLoadCallback(drawChart);

                        function drawChart() {

                            dates = <?php echo $datesJson; ?>;
                            string_prices = <?php echo $pricesJson; ?>;
                            prices = string_prices.map(parseFloat);

                            var data = new google.visualization.DataTable();
                            data.addColumn('string', 'Selected Date');
                            data.addColumn('number', 'Price');

                            for (let i = 0; i < dates.length; i++) {
                                data.addRow([dates[i], prices[i]]);
                            }

                            var options = {
                                title: 'user selection graph',
                                curveType: 'function',
                                legend: {
                                    position: 'bottom'
                                }
                            };

                            var chart = new google.visualization.LineChart(document.getElementById('curve_chart_<?php echo ($table_nb); ?>'));

                            chart.draw(data, options);
                        }
                    </script>

                    <script type="text/javascript">
                        google.charts.load('current', {
                            'packages': ['corechart']
                        });
                        google.charts.setOnLoadCallback(drawChart);

                        function drawChart() {

                            dates_db = <?php echo $datesJson_db; ?>;
                            string_prices_db = <?php echo $pricesJson_db; ?>;
                            prices_db = string_prices_db.map(parseFloat);

                            var data = new google.visualization.DataTable();
                            data.addColumn('string', 'Maching Date');
                            data.addColumn('number', 'Matching Price');

                            for (let i = 0; i < dates.length; i++) {
                                data.addRow([dates_db[i], prices_db[i]]);
                            }

                            var options = {
                                title: 'matching graph',
                                curveType: 'function',
                                legend: {
                                    position: 'bottom'
                                }
                            };

                            var chart = new google.visualization.LineChart(document.getElementById('curve_chart_db_<?php echo ($table_nb); ?>'));

                            chart.draw(data, options);
                        }
                    </script>

                    <br>

                    <div class="container flex">
                        <div id="curve_chart_<?php echo ($table_nb); ?>" style="width: 50%; height: 300px"></div>
                        <div id="curve_chart_db_<?php echo ($table_nb); ?>" style="width: 50%; height: 300px"></div>
                    </div>

                    <div class="container text-center">
                        <table class="tblfull">
                            <tr>
                                <th>ID</th>
                                <th>user selected date</th>
                                <th>closing price</th>
                                <th>matching pattern ID</th>
                                <th>date</th>
                                <th>closing price</th>
                                <th>matching level</th>
                            </tr>
                            <?php
                            for ($i = 0; $i < $nb_days; $i++) { ?>
                                <tr>
                                    <td><?php echo $id_array[$i]; ?></td>
                                    <td><?php echo $dates_array[$i]; ?></td>
                                    <td><?php echo $closing_prices_array[$i]; ?></td>
                                    <td><?php echo $id_array_db[$i]; ?></td>
                                    <td><?php echo $dates_array_db[$i]; ?></td>
                                    <td><?php echo $closing_prices_array_db[$i]; ?></td>
                                    <td><?php echo ($match_lvl * 100) . '%'; ?></td>
                                </tr>
                            <?php
                            }
                            ?>

                        </table>
                    </div>
                    <p>
                        <?php

                        print('the user selection variation: ');
                        foreach ($variation_array as $item) {
                            print($item . '  ');
                        }
                        print('<br>');
                        print('matching variation from database: ');
                        foreach ($variation_array_db as $item) {
                            print($item . '  ');
                        }
                        print('<br>');

                        ?>
                    </p>
                </div>
                <hr>
                <br><br><br>
        <?php
                $table_nb++;
            }

            //empty the arrays to store new data
            $closing_prices_array_db = [];
            $id_array_db = [];
            $dates_array_db = [];
            $distances_array_db = [];
            $variation_array_db = [];
        }
    } while ($count == $nb_days);

    if ($table_nb == 1) {
        ?>
        <div class="container">
            <h1 class="h1">No Matches Were Found</h1>
        </div>
    <?php
    }

    ?>

</body>

</html>