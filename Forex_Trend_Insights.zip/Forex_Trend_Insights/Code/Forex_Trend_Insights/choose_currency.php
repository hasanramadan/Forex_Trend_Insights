<?php
include('config/nav.php');
$gold = 'gold';
$platinum = 'platinum';
$silver = 'silver';
?>

<div class="container">
    <h2 class="text-center text-black">Choose Currency</h2>
</div>

<div class="btn-container">

    <a href="<?php echo SITEURL; ?>gold.php?id=<?php echo $gold; ?>">
        <div class="choose-currency-box">
            <div class="choose-currency-items">
                <p>
                    <i class="fas fa-coins fa-2x"></i>
                </p>
                <br><br>
                <h3>XAU</h3>
                <p class="currency-detail">
                    Gold, precious metal
                </p>
                <br>
            </div>
        </div>
    </a>

    <a href="<?php echo SITEURL; ?>silver.php?id=<?php echo $silver; ?>">
        <div class="choose-currency-box">
            <div class="choose-currency-items">
                <p>
                    <i class="fas fa-coins fa-2x"></i>
                </p>
                <br><br>
                <h3>XAG</h3>
                <p class="currency-detail">
                    Sliver, precious metal
                </p>
                <br>
            </div>
        </div>
    </a>

    <a href="<?php echo SITEURL; ?>platinum.php?id=<?php echo $platinum; ?>">
        <div class="choose-currency-box">
            <div class="choose-currency-items">
                <p>
                    <i class="fas fa-coins fa-2x"></i>
                </p>
                <br><br>
                <h3>XPT</h3>
                <p class="currency-detail">
                    platinum, precious metal
                </p>
                <br>
            </div>
        </div>
    </a>


    <div class="clearfix"></div>
</div>
</body>

</html>