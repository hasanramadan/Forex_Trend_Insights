<?php

require 'vendor/autoload.php';
use GuzzleHttp\Client;

// Function to fetch and insert data for a given currency
function fetchAndInsertData($currency, $table, $mysqli) {
    $client = new Client();
    $res = $client->get("https://api.tiingo.com/tiingo/daily/{$currency}USD/prices?startDate=2021-01-01&token=7d2a8d867650c1ce3ecb9a9dded7a53cd0214b5d", [
        'headers' => [
            'Content-type' =>  'application/json'
        ]
    ]);

    $data = json_decode($res->getBody(), true);

    // Delete existing data
    $mysqli->query("DELETE FROM $table");

    // Insert new data into MySQL database
    foreach ($data as $row) {
        $date = $row['date'];
        $close = $row['close'];
        $high = $row['high'];
        $low = $row['low'];
        $open = $row['open'];
        $volume = $row['volume'];
        $adjClose = $row['adjClose'];
        $adjHigh = $row['adjHigh'];
        $adjLow = $row['adjLow'];
        $adjOpen = $row['adjOpen'];
        $adjVolume = $row['adjVolume'];
        $divCash = $row['divCash'];
        $splitFactor = $row['splitFactor'];

        $query = "INSERT INTO $table (date, close, high, low, open, volume, adj_close, adj_high, adj_low, adj_open, adj_volume, div_cash, split_factor) 
                  VALUES ('$date', '$close', '$high', '$low', '$open', '$volume', '$adjClose', '$adjHigh', '$adjLow', '$adjOpen', '$adjVolume', '$divCash', '$splitFactor')";
        if ($mysqli->query($query) !== TRUE) {
            echo "Error: " . $query . "<br>" . $mysqli->error;
        }
    }
}

// Connect to MySQL database
$mysqli = new mysqli("localhost", "root", "", "forex_prices");

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Fetch and insert data for gold
fetchAndInsertData("XAU", "gold_prices", $mysqli);

// Fetch and insert data for platinum
fetchAndInsertData("XPT", "platinum_prices", $mysqli);

// Fetch and insert data for silver
fetchAndInsertData("XAG", "silver_prices", $mysqli);

// Close MySQL connection
$mysqli->close();

?>
