
window.addEventListener('load', function () {
    const slideInDiv = document.querySelector('.slide-in-div');
    slideInDiv.classList.add('slide-in');
});


