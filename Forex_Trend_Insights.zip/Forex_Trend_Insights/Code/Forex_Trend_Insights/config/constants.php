<?php

define('SITEURL','http://localhost/Forex_Trend_Insights/');

// Database connection
$mysqli = new mysqli("localhost", "root", "", "forex_prices");

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

?>