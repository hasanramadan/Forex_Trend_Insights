<?php

include('config/nav.php');

if (isset($_GET['id'])) {

    $currency = $_GET['id'];
} else {
    echo ('no currency was passed');
}

$sql = "SELECT * FROM silver_prices";
$res = mysqli_query($mysqli, $sql);

$closing_prices_array = [];
$dates_array = [];

if ($res == true) {

    $count = mysqli_num_rows($res);

    if ($count > 0) {

        while ($rows = mysqli_fetch_assoc($res)) {
            $user_selected_date = $rows['date'];
            $user_timestamp = strtotime($user_selected_date);
            $user_date = date('Y-m-d', $user_timestamp);
            $close_user_selection = $rows['close'];

            array_push($closing_prices_array, $close_user_selection);
            array_push($dates_array, $user_date);
        }
    }
} else {
    echo ('query fail');
}

$datesJson = json_encode($dates_array);
$pricesJson = json_encode($closing_prices_array);

?>

<div class="container">
    <h2 class="text-center text-black">Choose Date and Days</h2>

    <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>

    <script type="text/javascript">
        google.charts.load('current', {
            'packages': ['corechart']
        });
        google.charts.setOnLoadCallback(drawChart);

        function drawChart() {

            dates = <?php echo $datesJson; ?>;
            s_prices = <?php echo $pricesJson; ?>;
            prices = s_prices.map(parseFloat);

            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Date');
            data.addColumn('number', 'Price');

            for (let i = 0; i < dates.length; i++) {
                data.addRow([dates[i], prices[i]]);
            }

            var options = {
                title: 'Silver prices',
                curveType: 'function',
                legend: {
                    position: 'bottom'
                }
            };

            var chart = new google.visualization.LineChart(document.getElementById('curve_chart'));

            // Function to set the date selector value
            function setDateSelector(date) {
                // Convert the date string to a format acceptable by the date input
                const dateSelector = document.getElementById('start_date');
                const [year, month, day] = date.split('-');
                const formattedDate = `${year}-${month.padStart(2, '0')}-${day.padStart(2, '0')}`;
                dateSelector.value = formattedDate;
            }

            //to get the selected date from the graph
            google.visualization.events.addListener(chart, 'select', function() {
                var selection = chart.getSelection();
                if (selection.length > 0) {
                    var selectedItem = selection[0];
                    var date = data.getValue(selectedItem.row, 0);
                    var price = data.getValue(selectedItem.row, 1);
                    setDateSelector(date);
                }
            });

            chart.draw(data, options);
        }
    </script>

    <div id="curve_chart" style="width: 100%; height: 750px"></div>

    <form action="result1.php" method="post" class="curr">

        <label for="start_date" class="curr-label">Choose a Start Date:</label>
        <input type="date" id="start_date" name="start_date" class="input-responsive" required><br><br>
        

        <label for="days" class="curr-label">Number of Days Before:</label>
        <input type="number" id="days" name="days" min="3" class="input-responsive" required><br><br>

        <label for="days" class="curr-label">ATR (Volatility):</label>
        <input type="number" id="ATR" name="ATR_(Volatility)" min="50" max="500" step="50" class="input-responsive" required><br><br>

        <!-- Add a hidden input field to set the time portion of the date to "00:00:00" -->

        <input type="hidden" id="start_time" name="start_time" value="00:00:00">

        <input type="submit" name="submit" value="View Analysis" class="btn btn-primary">

        <input type="hidden" name="currency" value="<?php echo $currency; ?>">

    </form>
</div>
</body>

</html>
